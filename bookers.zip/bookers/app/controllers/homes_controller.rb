class HomesController < ApplicationController
  def 
  end
end
